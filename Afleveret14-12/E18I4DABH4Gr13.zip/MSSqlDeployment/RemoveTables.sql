﻿--ALTER TABLE [dbo].[ProsumerSmartMeterRecordsLogs] DROP CONSTRAINT [FK_ProsumerSmartMeterRecordsLogs_Prosumers_ProsumerID];
DROP TABLE [dbo].[__EFMigrationsHistory];
--DROP TABLE [dbo].[Prosumers];
--DROP TABLE [dbo].[ProsumerSmartMeterRecordsLogs];
DROP TABLE [dbo].[SmartGridProsumers];
DROP TABLE [dbo].[SmartGrids];